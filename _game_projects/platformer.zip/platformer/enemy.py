import pygame as pg


class Enemy(pg.sprite.Sprite):
    def __init__(self, x, y, *groups):
        super().__init__(*groups)
        self.image = pg.image.load("assets/tilemap-characters_packed.png").subsurface(pg.Rect((0, 48), (24, 24)))
        self.rect = pg.Rect(x, y, 18, 18)


    def update(self, dt):
        super().update(dt)
    

    