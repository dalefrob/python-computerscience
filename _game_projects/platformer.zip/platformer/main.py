import pygame as pg
import os
from camera import Camera
from coin import Coin
from game_utils import *
from player import Player
from enemy import Enemy
import resources
from spritegroup import SpriteGroup
from tilemap import *

FPS = 60

# Construct the path dynamically
current_dir = os.path.dirname(__file__)

testmap = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 3, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 5, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 0, 3, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 4, 4, 4, 5, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 0, 0, 3, 4, 4, 4, 4, 5, 0, 0],
]


class Game:
    def __init__(self):
        # Initialize your game systems here
        self.tilemap = Tilemap(...)  # Load your tilemap
        self.player = Player(x=100, y=100, width=50, height=50, game=self)

    def update(self, dt):
        # Update game systems (player, tilemap, etc.)
        self.player.update()

    def draw(self, screen):
        screen.fill("black")
        self.tilemap.draw(screen)
        self.player.draw(screen)


def main():
    pg.init()
    pg.mixer.init()
    flags = pg.SCALED
    screen = pg.display.set_mode((320, 280), flags)
    pg.display.set_caption("World Map!")

    # camera
    camera_rect = pg.Rect((0,0), (200,200))

    clock = pg.time.Clock()
    resources.load()

    # load resources
    player_spritesheet: pg.Surface = pg.image.load(os.path.join(
        current_dir, "assets/tilemap-characters_packed.png")).convert_alpha()
    tileset_texture = pg.image.load(os.path.join(
        current_dir, "assets/tilemap_packed.png")).convert_alpha()

    # initialize the map
    tileset_data = Tileset.load_tileset_data_json(
        os.path.join(current_dir, "assets/tileset_data.json"))
    tileset = Tileset(tileset_texture, tileset_data)
    tilemap = Tilemap(tileset, testmap)

    character_group = pg.sprite.Group()

    # init player
    player = Player(pg.Vector2(50, 50), load_animation_frames(
        player_spritesheet, 0, 0, 24, 1))
    player.add_animation("walk", load_animation_frames(
        player_spritesheet, 0, 0, 24, 2))
    player.add_animation("jump", load_animation_frames(
        player_spritesheet, 24, 0, 24, 1))
    character_group.add(player)

    # coin
    coins = pg.sprite.Group()
    coin = Coin((54, 90))
    coins.add(coin)

    # enemy
    enemy = Enemy(20,20, character_group)

    # Make this the size of the world
    game_canvas = pg.Surface((600, 280))

    running = True
    while running:
        dt = min(clock.tick(60) / 1000.0, 0.05)

        game_canvas.fill("black")

        player.handle_input(pg.key.get_pressed())
        
        player.update(dt)
        # check collisions
        response = resolve_tilemap_collision(player.collision_rect, tilemap)
        if response:
            push_vector, normal = response
            # Move the player out of collision
            player.position += push_vector

            # Cancel velocity in the direction of collision
            if normal.x != 0:
                player.velocity.x = 0
            if normal.y != 0:
                if normal.y < 0:
                    player.on_ground = True
                player.velocity.y = 0

        # coin collision
        coll_object: Coin = pg.sprite.spritecollideany(player, coins)
        if coll_object:
            print(coll_object)  
            coll_object.kill()
            pg.mixer.Sound.play(resources.sounds["pickup"])
            del coll_object

        
        
        coin.update(dt)
        enemy.update(dt)

        tilemap.draw(game_canvas)
        coins.draw(game_canvas)
        character_group.draw(game_canvas)

        print(f"Position: {player.position}, Rect Center: {player.rect.center}")
        camera_rect.center = player.collision_rect.center
        camera_rect.clamp_ip(game_canvas.get_rect())
        screen.blit(game_canvas, (0,0), camera_rect)

        pg.display.flip()

        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                running = False


if __name__ == "__main__":
    main()
